export interface Character {
  handle: string
  name: string
  profilePicture: string
  shortDescription: string
  bio: string
}
